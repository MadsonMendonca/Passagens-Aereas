<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "bd_aero");
if (!$conn) {
    echo("Deu ruim!!");
}
echo("Conexão criada com sucesso!!");

$user = $_POST['user'];
$email = $_POST["email"];
$senha = $_POST["senha"];

$sql = "SELECT user, id FROM usuario WHERE (email = '$email' OR user = '$user') AND senha = '$senha'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_array($result);
    $_SESSION['user'] = $row['user'];
    $_SESSION['id'] = $row['id'];
    // Redirecionamento para index.html com os parâmetros na URL
    header('Location: https://localhost/aeroPrj/index.php?id=' . $row['id'] . '&user=' . urlencode($row['user']));
} else {
    echo '<script>alert("Usuário ou senha inválidos!!");</script>';
    echo '<script>window.location.href = "https://localhost/aeroPrj/login.html";</script>';
}

?>

