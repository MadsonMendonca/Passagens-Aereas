<?php
// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=bd_aero';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // atualização
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Recebe os dados enviados via POST
        $data = json_decode(file_get_contents("php://input"), true);

        // Verifica se os dados necessários foram recebidos
        if (isset($data['idPedido']) && isset($data['novaOrigem']) && isset($data['novoDestino']) && isset($data['novaClasse']) && isset($data['novaData'])) {
            $idPedido = $data['idPedido'];
            $novaOrigem = $data['novaOrigem'];
            $novoDestino = $data['novoDestino'];
            $novaClasse = $data['novaClasse'];
            $novaData = $data['novaData'];

            // Atualiza o atributo "origem" no banco de dados
            $stmtAtualizacao = $pdo->prepare("UPDATE pedido SET origem = :novaOrigem, destino = :novoDestino, classe = :novaClasse, data = :novaData, precoTotal = precoTotal * 1.4  WHERE id_pedido = :idPedido");
            $stmtAtualizacao->execute([                
                ':novaOrigem' => $data['novaOrigem'],
                ':novoDestino' => $data['novoDestino'],                
                ':idPedido' => $data['idPedido'],
                ':novaClasse' => $data['novaClasse'],
                ':novaData' => $data['novaData'],
            ]);

            http_response_code(200);
        } else {
            http_response_code(400);
        }
        /// DELETAR
    } else if($_SERVER['REQUEST_METHOD'] === 'DELETE'){
        $data = json_decode(file_get_contents("php://input"), true);

        $stmtDeletarPassagem = $pdo->prepare("DELETE FROM passagem WHERE id_pedido = :idPedido");
        $stmtDeletarPassagem->execute([
            ':idPedido' => $data['idPedido']
        ]); 

        $stmtDeletarPedido = $pdo->prepare("DELETE FROM pedido WHERE id_pedido = :idPedido");
        $stmtDeletarPedido->execute([
            ':idPedido' => $data['idPedido']
        ]); 



    } else {
        // Consulta ao banco de dados
        $stmtConsulta = $pdo->query('SELECT * FROM pedido');
        $dados = $stmtConsulta->fetchAll(PDO::FETCH_ASSOC);

        // Envia os dados como JSON para o cliente
        echo json_encode($dados);
    }
} catch (PDOException $e) {
    echo 'Erro ao conectar ao banco de dados: ' . $e->getMessage();
}
?>
