<?php
$dsn = 'mysql:host=localhost;dbname=bd_aero';
$username = 'root';
$password = '';


try{
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmtconsultar = $pdo->query('SELECT * FROM passagem');
    
    $dados_passageiro = $stmtconsultar->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($dados_passageiro);
} catch (PDOException $e){
    echo "Erro ao se conectar ao banco de dados" . $e->getMessage();
}

