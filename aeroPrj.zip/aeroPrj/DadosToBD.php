<?php

// Recupera os dados enviados via POST
$data = json_decode(file_get_contents("php://input"), true);

$dsn = 'mysql:host=localhost;dbname=bd_aero';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Inserir dados na tabela 'pedido'
    $stmtPedido = $pdo->prepare("INSERT INTO pedido (userID, user, origem, destino, classe, data, passageiros, precoTotal) VALUES (:userID, :user, :origem, :destino, :classe, :data, :passageiros, :precoTotal)");
    $stmtPedido->execute([
        ':userID' => $data['userID'],
        ':user' => $data['user'],
        ':origem' => $data['origem'],
        ':destino' => $data['destino'],
        ':classe' => $data['classe'],
        ':data' => $data['data'],
        ':passageiros' => $data['passageiros'],
        ':precoTotal' => $data['precoTotal']
    ]);

    // Recupera o ID do pedido inserido
    $pedidoId = $pdo->lastInsertId();

    // localStorage
    foreach ($data['passageirosArmazenados'] as $passageiro) {
        $stmtPassagem = $pdo->prepare("INSERT INTO passagem (nomePassageiro, cpfPassageiro, poltronaID, precoUnitario, userID, user, id_pedido) VALUES (:nomePassageiro, :cpfPassageiro, :poltronaID, :precoUnitario, :userID, :user, :id_pedido)");
        $stmtPassagem->execute([
            ':nomePassageiro' => $passageiro['nomePassageiro'],
            ':cpfPassageiro' => $passageiro['cpfPassageiro'],
            ':poltronaID' => $passageiro['poltronaID'],
            ':precoUnitario' => $passageiro['precoUnitario'],
            ':userID' => $data['userID'], // Usando o userID do pedido
            ':user' => $data['user'],
            ':id_pedido' => $pedidoId // Usando o ID do pedido como id_pedido na tabela passagem
        ]);
    }

    echo "Dados inseridos com sucesso no banco de dados!";
} catch (PDOException $e) {
    echo "Erro ao inserir os dados no banco de dados: " . $e->getMessage();
}
?>
