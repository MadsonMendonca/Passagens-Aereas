<?php
// Conecta ao banco de dados
$conn = mysqli_connect("localhost", "root", "", "bd_aero");

// Verifica a conexão
if (!$conn) {
    die("Falha na conexão: " . mysqli_connect_error());
}

// Obtém os dados do formulário
$cpf = $_POST['cpf'];
$nome = $_POST['nome'];
$endereco = $_POST['endereco'];
$telefone = $_POST['telefone'];
$sexo = $_POST['sexo'];
$email = $_POST['email'];
$user = $_POST['user'];
$senha = $_POST['senha'];

// Verifica se o nome já existe no banco de dados
$sql_check = "SELECT COUNT(*) AS count FROM usuario WHERE user = '$user'";
$result_check = mysqli_query($conn, $sql_check);
$row_check = mysqli_fetch_assoc($result_check);
if ($row_check['count'] > 0) {
    // Usuário já existe, exibe mensagem de erro
    echo "<script>alert('Nome de usuário já está em uso. Por favor, escolha outro nome.');</script>";
    echo "<script>setTimeout(function(){window.location.href = 'cadastro.html';}, 500);</script>";

} else {
    // Insere o novo usuário no banco de dados
    // ...
}


// Prepara a consulta SQL
$sql = "INSERT INTO usuario (cpf, nome, endereco, telefone, sexo, email, user, senha) VALUES ('$cpf', '$nome', '$endereco', '$telefone', '$sexo', '$email', '$user', '$senha')";


// Executa a consulta SQL
if (mysqli_query($conn, $sql)) {
    echo "";
} else {
    echo "Erro ao inserir dados: " . mysqli_error($conn);
}


// Fecha a conexão
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_inserir_dados.css">
    <title>CADASTRO EFETUADO COM SUCESSO</title>
</head>
<body>
    <div>
    <h2>Cadastro efetuado com sucesso!</h2>
    <a href="login.html"><input type="submit" value="LOGIN"></a>
    </div>
</body>
</html>