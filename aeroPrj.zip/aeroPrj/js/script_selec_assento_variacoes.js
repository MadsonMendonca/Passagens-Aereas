var divsAssento = document.querySelectorAll('#lado_esquerdo div, #lado_direito div');
var passageirosPermitidos = parseInt(document.getElementById('passageiros').value);
var passageirosSelecionados = 0;

divsAssento.forEach(function(divAssento) {
    divAssento.addEventListener('mouseover', function() {
        this.style.backgroundColor = '#9c8d07'; // Muda a cor de fundo quando o mouse passa sobre a div
    });

    divAssento.addEventListener('mouseout', function() {
        if (!divAssento.classList.contains('selected')) {
            this.style.backgroundColor = ''; // Retorna à cor original quando o mouse sai da div, se não estiver selecionado
        }
    });

    divAssento.addEventListener('click', function() {
        if (divAssento.classList.contains('selected')) {
            divAssento.classList.remove('selected'); // Remove a classe 'selected' se já estiver selecionado
            passageirosSelecionados--; // Reduz o número de passageiros selecionados
            location.reload(); 
        } else {
            if (passageirosSelecionados < passageirosPermitidos) {
                divAssento.classList.add('selected'); // Adiciona a classe 'selected' se não estiver selecionado
                passageirosSelecionados++; // Aumenta o número de passageiros selecionados
                abrirModal(divAssento.id); // Abre o modal ao clicar na poltrona
            } else {
                alert("Você já selecionou o número máximo de passageiros permitidos.");
            }
        }

        atualizarContadorPassageiros(passageirosSelecionados); // Atualiza o contador de passageiros
    });
});

// Função para atualizar o contador de passageiros
function atualizarContadorPassageiros(passageiros) {
    var passageirosInput = document.getElementById('passageiros');
    passageirosInput.value = passageiros;
}

//// ADICIONAR PASSAGEIRO ////

// Função para abrir o modal
function abrirModal(poltronaId) {
    var modal = document.getElementById('modal');
    modal.style.display = 'block';

    // Quando o usuário clicar em Fechar (x), feche o modal
    var span = document.getElementsByClassName('fechar')[0];
    span.onclick = function() {
        modal.style.display = 'none';
    };

    var confirmarBtn = document.getElementById('confirmar');
    confirmarBtn.onclick = function() {
        var nome = document.getElementById('nomeModal').value;
        var cpf = document.getElementById('cpfModal').value;
        var telefone = document.getElementById('telefoneModal').value;

        // Validando os dados inseridos
        if (!validarNome(nome) || !validarCPF(cpf) || !validarTelefone(telefone)) {
            alert("Por favor, preencha todos os campos corretamente.");
            return;
        }

        // Criando um objeto para representar os detalhes do passageiro
        var passageiro = {
            poltronaId: poltronaId,
            nome: nome,
            cpf: cpf,
            telefone: telefone
        };

        // Verificando se já existe uma lista de passageiros armazenada em localStorage
        var passageirosArmazenados = JSON.parse(localStorage.getItem('passageiros')) || [];

        // Adicionando o novo passageiro à lista
        passageirosArmazenados.push(passageiro);

        // Armazenando a lista atualizada de passageiros em localStorage
        localStorage.setItem('passageiros', JSON.stringify(passageirosArmazenados));

        // Criando um objeto para representar os detalhes do passageiro a ser exibido
        var detalhesPassageiro = document.createElement('p');
        detalhesPassageiro.textContent = '[' + poltronaId +']' + nome;

        // Adicionando os detalhes do passageiro à div principal_3
        var principal_3 = document.getElementById('principal_3');
        principal_3.appendChild(detalhesPassageiro);
        
        // Fechando o modal após confirmar os detalhes do passageiro
        modal.style.display = 'none';

        // Limpando os campos após fechar o modal
        document.getElementById('nomeModal').value = '';
        document.getElementById('cpfModal').value = '';
        document.getElementById('telefoneModal').value = '';
    };
}

//// FUNÇÕES DE VALIDAÇÃO ////

// Validação do nome
function validarNome(nome) {
    return nome.trim() !== '';
}

// Validação do CPF
function validarCPF(cpf) {
    return /^\d{11}$/.test(cpf);

}

// Validação do telefone
function validarTelefone(telefone) {
    telefone = telefone.replace(/[^\d]/g, '')
    return telefone.trim() !== '';
}

//// LIMPAR O DATASTORAGE ////

localStorage.removeItem('passageiros');