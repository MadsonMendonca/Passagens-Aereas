var xhr = new XMLHttpRequest();
xhr.open('GET', 'php/php_status_voo2.php', true);
xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
            var dados_passageiro = JSON.parse(xhr.responseText);
            var dadosBody = document.getElementById('dados-body');
            var user = localStorage.getItem('user'); 
            
            // Filtra os dados de acordo com o usuário do Local Storage
            dados_passageiro.forEach(function(dado) {
                if (dado.user === user) { // Verifica se o usuário do dado é igual ao usuário do Local Storage
                    var row = document.createElement('tr');
                    row.innerHTML = '<td>' + dado.id_pedido + '</td>' +
                                    '<td>' + dado.id_passagem + '</td>' +
                                    '<td>' + dado.user + '</td>' +
                                    '<td>' + dado.nomePassageiro + '</td>' +
                                    '<td>' + dado.cpfPassageiro + '</td>' +                                    
                                    '<td>' + dado.poltronaID + '</td>'
                                   
                    dadosBody.appendChild(row);
                }
            });
        }
    }
};

xhr.send();




document.getElementById('BtnVoltar').addEventListener('click', function(){
    var urlParams = new URLSearchParams(window.location.search);
    var id = urlParams.get('id');
    var user = urlParams.get('user');


    var url = 'status_voo.html?id=' + encodeURIComponent(id) + '&user=' + encodeURIComponent(user);
    window.location.href = url;
    
});