// Função para obter o valor do parâmetro "user" da URL
function getUsuarioFromURL() {
    var urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('user');
}

// Função para fazer login
function fazerLogin() {
    var usuario = getUsuarioFromURL();
    var button = document.getElementById('button-login-cabecalho');
    var irParaProximaPaginaButton = document.getElementById('irParaProximaPagina');


    // Verificando se o parâmetro "user" está presente na URL
    if (usuario) {
        // Limitando o nome de usuário a 10 caracteres
        if (usuario.length > 10) {
            usuario = usuario.substring(0, 7) + '..';
        }

        // Substituindo o conteúdo do botão pelo ícone e a mensagem de boas-vindas
        button.innerHTML = '<i class="fas fa-user"></i>Bem-vindo, <br>' + usuario;
        button.disabled = true; // Desativa o botão após fazer login

        // Habilitando o botão "IrParaProximaPagina" se o usuário estiver logado
        irParaProximaPaginaButton.disabled = false;
    } else {
        // Desativando o botão "IrParaProximaPagina" se o usuário não estiver logado
        irParaProximaPaginaButton.disabled = true;
    }
}

// Função para redirecionar para a próxima página
function irParaProximaPagina() {
    // Aqui você pode colocar a lógica para redirecionar para a próxima página
    window.location.href = "selecionarVoo.html";
}

// Chama a função fazerLogin ao carregar a página
document.addEventListener("DOMContentLoaded", fazerLogin);

document.getElementById("status_voo").addEventListener('click', function(event){
    var urlParams = new URLSearchParams(window.location.search);
    var id = urlParams.get('id');
    var user = urlParams.get('user');

    var url = 'status_voo.html?id=' + encodeURIComponent(id) + '&user=' + encodeURIComponent(user);
    window.location.href = url;
});

//// CLICAR NA LOGO E REDIRECIONAR AO INDEX ////

document.getElementById('logo').addEventListener('click', function(event){
    var urlParams = new URLSearchParams(window.location.search);
    var id = urlParams.get('id');
    var user = urlParams.get('user');

    var url = 'index.php?id=' + encodeURIComponent(id) + '&user=' + encodeURIComponent(user);
    window.location.href = url;
});


//// ARMAZENA NO LOSTORAGE ID E USER /////

// Função para extrair parâmetros da URL
function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}

// Extrair valores de "id" e "user" da URL
var id = getUrlParameter('id');
var user = getUrlParameter('user');

// Armazenar os valores no localStorage
localStorage.setItem('id', id);
localStorage.setItem('user', user);


