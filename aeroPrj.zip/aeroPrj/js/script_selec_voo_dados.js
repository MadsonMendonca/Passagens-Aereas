// Função para obter os parâmetros da URL
function obterParametrosDaURL() {
    var urlSearchParams = new URLSearchParams(window.location.search);
    var params = Object.fromEntries(urlSearchParams.entries());
    return params;
}

var parametros = obterParametrosDaURL();

// lista com os dados recebidos
var dadosRecebidos = [
    { chave: 'Id', valorId: parametros.id },
    { chave: 'User', valorUser: parametros.user },
    { chave: 'Origem', valorOrigem: parametros.origem },
    { chave: 'Destino', valorDestino: parametros.destino },
    { chave: 'Trajeto', valorTrajeto: parametros.trajeto },
    { chave: 'Classe', valorClasse: parametros.classe },
    { chave: 'Dataida', valorDataida: parametros.dataida },
    { chave: 'Datavolta', valorDatavolta: parametros.datavolta },
    { chave: 'Adulto', valorAdulto: parametros.adulto },
    { chave: 'Crianca', valorCrianca: parametros.crianca },

];

// Selecionar o elemento input
var inputDadosRecebidosId = document.getElementById('id');
var inputDadosRecebidosUser = document.getElementById('user');
var inputDadosRecebidosOrigem = document.getElementById('origem');
var inputDadosRecebidosDestino = document.getElementById('destino');
var inputDadosRecebidosTrajeto = document.getElementById('trajeto');
var inputDadosRecebidosClasse = document.getElementById('classe');
var inputDadosRecebidosDataida = document.getElementById('dataida');
var inputDadosRecebidosDatavolta = document.getElementById('datavolta');
var inputDadosRecebidosAdulto = document.getElementById('adulto');
var inputDadosRecebidosCrianca = document.getElementById('crianca');

// Atribuir os valores ao valor do input
inputDadosRecebidosId.value = dadosRecebidos.map(function(item){
    return item.valorId;
}).join('');
inputDadosRecebidosUser.value = dadosRecebidos.map(function(item){
    return item.valorUser;
}).join('');
inputDadosRecebidosOrigem.value = dadosRecebidos.map(function(item){
    return item.valorOrigem;
}).join('');
inputDadosRecebidosDestino.value = dadosRecebidos.map(function(item){
    return item.valorDestino;
}).join('');
inputDadosRecebidosTrajeto.value = dadosRecebidos.map(function(item){
    return item.valorTrajeto;
}).join('');
inputDadosRecebidosClasse.value = dadosRecebidos.map(function(item){
    return item.valorClasse;
}).join('');
inputDadosRecebidosDataida.value = dadosRecebidos.map(function(item){
    return item.valorDataida;
}).join('');
inputDadosRecebidosDatavolta.value = dadosRecebidos.map(function(item){
    return item.valorDatavolta;
}).join('');
inputDadosRecebidosAdulto.value = dadosRecebidos.map(function(item){
    return item.valorAdulto;
}).join('');
inputDadosRecebidosCrianca.value = dadosRecebidos.map(function(item){
    return item.valorCrianca;
}).join('');