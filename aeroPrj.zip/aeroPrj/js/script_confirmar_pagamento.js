//// SEPARANDO A URL E OBTENDO OS DADOS ////

function obterParametrosDaURL() {
    var urlSearchParams = new URLSearchParams(window.location.search);
    var params = Object.fromEntries(urlSearchParams.entries());
    return params;
}

var parametros = obterParametrosDaURL();

// Criar uma array com os dados recebidos
var dadosRecebidos = [
    { chave: 'Id', valorId: parametros.id },
    { chave: 'User', valorUser: parametros.user },
    { chave: 'Origem', valorOrigem: parametros.origem },
    { chave: 'Destino', valorDestino: parametros.destino },
    { chave: 'Trajeto', valorTrajeto: parametros.trajeto },
    { chave: 'Classe', valorClasse: parametros.classe },
    { chave: 'Dataida', valorDataida: parametros.dataida },
    { chave: 'Passageiros', valorPassageiros: parametros.passageiros },
    { chave: 'Preco', valorPreco: parametros.preco },    
];

// Selecionar o elemento input
var inputDadosRecebidosId = document.getElementById('id');
var inputDadosRecebidosUser = document.getElementById('user');
var inputDadosRecebidosOrigem = document.getElementById('origem');
var inputDadosRecebidosDestino = document.getElementById('destino');
var inputDadosRecebidosTrajeto = document.getElementById('trajeto');
var inputDadosRecebidosClasse = document.getElementById('classe');
var inputDadosRecebidosDataida = document.getElementById('dataida');
var inputDadosRecebidosPassageiros = document.getElementById('passageiros');
var inputDadosRecebidosPreco = document.getElementById('preco');

// Atribuir os valores ao valor do input
inputDadosRecebidosId.value = dadosRecebidos.map(function(item){
    return item.valorId;
}).join('');
inputDadosRecebidosUser.value = dadosRecebidos.map(function(item){
    return item.valorUser;
}).join('');
inputDadosRecebidosOrigem.value = dadosRecebidos.map(function(item){
    return item.valorOrigem;
}).join('');
inputDadosRecebidosDestino.value = dadosRecebidos.map(function(item){
    return item.valorDestino;
}).join('');
inputDadosRecebidosTrajeto.value = dadosRecebidos.map(function(item){
    return item.valorTrajeto;
}).join('');
inputDadosRecebidosClasse.value = dadosRecebidos.map(function(item){
    return item.valorClasse;
}).join('');
inputDadosRecebidosDataida.value = dadosRecebidos.map(function(item){
    return item.valorDataida;
}).join('');
inputDadosRecebidosPassageiros.value = dadosRecebidos.map(function(item){
    return item.valorPassageiros;
}).join('');
inputDadosRecebidosPreco.value = dadosRecebidos.map(function(item){
    return item.valorPreco;
}).join('');


//// DADOS DOS PASSAGEIROS ////

// Função para abrir a aba correspondente ao clicar em um botão de aba
function openTab(evt, tabId) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName('tabcontent');
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = 'none';
    }
    tablinks = document.getElementsByClassName('tablinks');
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(' active', '');
    }
    document.getElementById(tabId).style.display = 'block';
    evt.currentTarget.className += ' active';
}

// Recuperando a lista de passageiros armazenada em localStorage
var passageirosArmazenados = JSON.parse(localStorage.getItem('passageiros')) || [];

// Criando abas para cada passageiro
passageirosArmazenados.forEach(function(passageiro, index) {
    var poltronaId = passageiro.poltronaId;
    var nome = passageiro.nome;
    var cpf = passageiro.cpf;
    var telefone = passageiro.telefone

    // Criando a aba para o passageiro
    var tab = document.createElement('div');
    tab.className = 'tab';
    tab.id = 'tab_' + index;
    tab.innerHTML = '<button class="tablinks" onclick="openTab(event, \'tabContent_' + index + '\')">Passageiro ' + (index + 1) + '</button>';
    document.querySelector('.tabs').appendChild(tab);

    // Criando o conteúdo da aba para o passageiro
    var tabContent = document.createElement('div');
    tabContent.id = 'tabContent_' + index;
    tabContent.className = 'tabcontent';
    var passageiroDetails = document.createElement('p');
    passageiroDetails.innerHTML = ' &nbsp; &nbsp; &nbsp; &nbsp; Nome: ' + nome + '<br><br> &nbsp; &nbsp; &nbsp; &nbsp; CPF: ' + cpf + '<br><br>  &nbsp; &nbsp; &nbsp; &nbsp; Telefone: ' + telefone + '<br><br>  &nbsp; &nbsp; &nbsp; &nbsp; Poltrona: ' + poltronaId;
    tabContent.appendChild(passageiroDetails);

    // Adicionando o conteúdo da aba abaixo das abas
    document.querySelector('.tabs-content').appendChild(tabContent);
});

// Exibir a primeira aba por padrão
document.getElementById('tabContent_geral').style.display = 'block';
document.querySelector('.tablinks').className += ' active';


