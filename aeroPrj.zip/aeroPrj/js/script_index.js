////  ABAS (OK)  ////
function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Abrir a primeira aba por padrão
document.getElementById("aba1").style.display = "block";
document.getElementsByClassName("tablinks")[0].className += " active";

//// FECHAR BALÃO DE INFORMAÇÃO (OK) /////
document.addEventListener("DOMContentLoaded", function() {
    var balao = document.getElementById("balao");
    var botaoFechar = document.getElementById("fecharBalao");

    botaoFechar.addEventListener("click", function() {
        balao.style.display = "none"; // Oculta o balão quando o botão é clicado
    });
});

//// SELEÇÃO DA IDA E VOLTA (DATA) //// (OK)

var selectTrajeto = document.getElementById('trajeto');
var dataIda = document.getElementById('dataida');
var dataVolta = document.getElementById('datavolta');
var datalabVolta = document.getElementById('data2');

function definirValoresPadraoParaDatas() {
    dataIda.value = '';
    dataVolta.value = '';
}

definirValoresPadraoParaDatas();

// Esconder o input do datavolta
selectTrajeto.addEventListener('change', function() {
    if (selectTrajeto.value === 'ida') {
        dataVolta.disabled = true;
        dataVolta.style.display = 'none';
        datalabVolta.style.display = 'none';
        dataIda.disabled = false;
        definirValoresPadraoParaDatas();
    } else if (selectTrajeto.value === 'ida e volta'){
        dataVolta.disabled = false;
        dataVolta.style.display = '';
        datalabVolta.style.display = '';
        dataIda.disabled = false;
        definirValoresPadraoParaDatas();
    }
});  

//// SELEÇÃO DA QUANTIDADE DE PASSAGEIRO (OK) ////

document.addEventListener("DOMContentLoaded", function() {
    var passageiro = document.getElementById("passageiros");
    var adulto = document.getElementById("qtd-passag-adulto");
    var crianca = document.getElementById("qtd-passag-crianca");    

    function definirValorPadrãoPassageiro(){
        adulto.value = 1;
        crianca.value = 0;
    };
    
    definirValorPadrãoPassageiro();

    passageiro.addEventListener("change", function() {
        if (passageiro.value == "passageiro1") {
            adulto.disabled = false; 
            crianca.disabled = true;
            definirValorPadrãoPassageiro(); 
        } 
        else if(passageiro.value == "passageiro2"){
            adulto.disabled = false; 
            crianca.disabled = false;
            definirValorPadrãoPassageiro(); 
        }       
    });
});

//// VALIDAÇÃO DAS DATAS (OK) ////

function validarDatas() {
    var dataIda = new Date(document.getElementById("dataida").value);
    var dataVolta = new Date(document.getElementById("datavolta").value);

    var dataAtual = new Date();

    if (dataIda < dataAtual) {
        alert("Data inválida!");
        definirValoresPadraoParaDatas();
        return;
    }

    if (dataVolta < dataIda) {
        alert("Data inválida!");
        definirValoresPadraoParaDatas();
        return;
    }    
};

//// BUSCAR OS DADOS DA URL /////
function obterParametrosDaURL() {
    var urlSearchParams = new URLSearchParams(window.location.search);
    var params = Object.fromEntries(urlSearchParams.entries());
    return params;
}

var parametros = obterParametrosDaURL();

// Criar uma array com os dados recebidos
var dadosRecebidos = [
    { chave: 'Id', valorId: parametros.id },
    { chave: 'Usuario', valorUsuario: parametros.user }
];

var inputDadosRecebidosId = document.getElementById('id');
var inputDadosRecebidosUsuario = document.getElementById('user');

inputDadosRecebidosId.value = dadosRecebidos.map(function(item){
    return item.valorId;
}).join('');
inputDadosRecebidosUsuario.value = dadosRecebidos.map(function(item){
    return item.valorUsuario;
}).join('');
