document.getElementById("irParaProximaPagina").addEventListener("click", function(event) {
    var id = document.getElementById("id").value;
    var usera = document.getElementById('user').value;
    var origem = document.getElementById("origem").value;
    var destino = document.getElementById("destino").value;
    var trajeto = document.getElementById('trajeto').value;
    var classe = document.getElementById('classe-economica').value;
    var dataida = document.getElementById('dataida').value;
    var datavolta = document.getElementById('datavolta').value;
    var adulto = document.getElementById('qtd-passag-adulto').value;
    var crianca = document.getElementById('qtd-passag-crianca').value;

    var origemInput = document.getElementById("origem");
    var destinoInput = document.getElementById("destino");
    var datalistOptions = Array.from(document.getElementById("lista-aeroportos").options).map(option => option.value);

    var origemValue = origemInput.value;
    var destinoValue = destinoInput.value;

    var origemValid = false;
    var destinoValid = false;

    // Verificação se os valores de origem e destino estão na lista de opções
    for (var i = 0; i < datalistOptions.length; i++) {
        if (origemValue === datalistOptions[i]) {
            origemValid = true;
            break;
        }
    }

    for (var j = 0; j < datalistOptions.length; j++) {
        if (destinoValue === datalistOptions[j]) {
            destinoValid = true;
            break;
        }
    }

    // Condição para verificar se todos os campos obrigatórios foram preenchidos
    if (origem === "" || destino === "" || trajeto === "" || classe === "" || dataida === "" || adulto === "") {
        alert("Por favor, preencha todos os campos.");
    } else if(origem === destino) { // Verifica se origem é igual a destino
        alert("O destino deve ser diferente da origem");
    } else if (origemValid && destinoValid) { // Verifica se os valores de origem e destino são válidos

        console.log("Origem válida:", origemValue);
        console.log("Destino válido:", destinoValue);

        //// MONTAGEM DA URL ////
        var url = 'selecionarVoo.php?id=' + encodeURIComponent(id) + '&origem=' + encodeURIComponent(origem) 
        + '&destino=' + encodeURIComponent(destino) + '&trajeto=' + encodeURIComponent(trajeto) + '&classe=' + encodeURIComponent(classe)
        + '&dataida=' + encodeURIComponent(dataida) + '&datavolta=' + encodeURIComponent(datavolta)
        +  '&adulto=' + encodeURIComponent(adulto) +  '&crianca=' + encodeURIComponent(crianca) + '&user=' + encodeURIComponent(usera) ; 
        window.location.href = url; 
    } else {
        // Exibe alertas se os valores de origem e/ou destino não forem válidos
        if (!origemValid) {
            alert("O valor de origem inserido não é válido. Por favor, selecione uma opção da lista.");
            origemInput.value = ""; // Limpa o campo se o valor não for válido
        }

        if (!destinoValid) {
            alert("O valor de destino inserido não é válido. Por favor, selecione uma opção da lista.");
            destinoInput.value = ""; // Limpa o campo se o valor não for válido
        }
    }

    event.preventDefault(); // Impede o envio do formulário
});
