
document.addEventListener('DOMContentLoaded', function() {
    var inputField = document.getElementById('usuario');
    var label = inputField.nextElementSibling;

    inputField.addEventListener('focus', function() {
        label.classList.add('active');
    });

    inputField.addEventListener('blur', function() {
        if (inputField.value === '') {
            label.classList.remove('active');
        }
    });

    // Verifica se o campo de entrada já tem texto ao carregar a página
    if (inputField.value !== '') {
        label.classList.add('active');
    }
});


//// BOTÃO MUDAR DE COR ////
document.addEventListener('DOMContentLoaded', function() {
    var buttonEntrar = document.getElementById('button_entrar');
    var buttonCadastrar = document.getElementById('button_cadastrar');

    buttonEntrar.addEventListener('mouseover', function() {
        buttonEntrar.style.backgroundColor = 'lightseagreen';
    });

    buttonEntrar.addEventListener('mouseout', function() {
        buttonEntrar.style.backgroundColor = ''; 
    });

    buttonCadastrar.addEventListener('mouseover', function() {
        buttonCadastrar.style.backgroundColor = 'lightgreen';
    });

    buttonCadastrar.addEventListener('mouseout', function() {
        buttonCadastrar.style.backgroundColor = ''; 
    });
});


