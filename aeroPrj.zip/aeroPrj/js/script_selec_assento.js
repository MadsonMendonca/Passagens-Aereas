//// SEPARANDO A URL E OBTENDO OS DADOS ////

function obterParametrosDaURL() {
    var urlSearchParams = new URLSearchParams(window.location.search);
    var params = Object.fromEntries(urlSearchParams.entries());
    return params;
}

var parametros = obterParametrosDaURL();

// Criar uma lista com os dados recebidos
var dadosRecebidos = [
    { chave: 'Id', valorId: parametros.id },
    { chave: 'User', valorUser: parametros.user },
    { chave: 'Origem', valorOrigem: parametros.origem },
    { chave: 'Destino', valorDestino: parametros.destino },
    { chave: 'Trajeto', valorTrajeto: parametros.trajeto },
    { chave: 'Classe', valorClasse: parametros.classe },
    { chave: 'Dataida', valorDataida: parametros.dataida },
    { chave: 'Datavolta', valorDatavolta: parametros.datavolta },
    { chave: 'Passageiros', valorPassageiros: parametros.passageiros },
    { chave: 'Preco', valorPreco: parametros.preco },
    
];

// Selecionar o elemento input
var inputDadosRecebidosId = document.getElementById('id');
var inputDadosRecebidosUser = document.getElementById('user');
var inputDadosRecebidosOrigem = document.getElementById('origem');
var inputDadosRecebidosDestino = document.getElementById('destino');
var inputDadosRecebidosTrajeto = document.getElementById('trajeto');
var inputDadosRecebidosClasse = document.getElementById('classe');
var inputDadosRecebidosDataida = document.getElementById('dataida');
var inputDadosRecebidosDatavolta = document.getElementById('datavolta');
var inputDadosRecebidosPassageiros = document.getElementById('passageiros');
var inputDadosRecebidosPreco = document.getElementById('preco');

// Atribuir os valores ao valor do input
inputDadosRecebidosId.value = dadosRecebidos.map(function(item){
    return item.valorId;
}).join('');
inputDadosRecebidosUser.value = dadosRecebidos.map(function(item){
    return item.valorUser;
}).join('');
inputDadosRecebidosOrigem.value = dadosRecebidos.map(function(item){
    return item.valorOrigem;
}).join('');
inputDadosRecebidosDestino.value = dadosRecebidos.map(function(item){
    return item.valorDestino;
}).join('');
inputDadosRecebidosTrajeto.value = dadosRecebidos.map(function(item){
    return item.valorTrajeto;
}).join('');
inputDadosRecebidosClasse.value = dadosRecebidos.map(function(item){
    return item.valorClasse;
}).join('');
inputDadosRecebidosDataida.value = dadosRecebidos.map(function(item){
    return item.valorDataida;
}).join('');
inputDadosRecebidosDatavolta.value = dadosRecebidos.map(function(item){
    return item.valorDatavolta;
}).join('');
inputDadosRecebidosPassageiros.value = dadosRecebidos.map(function(item){
    return item.valorPassageiros;
}).join('');
inputDadosRecebidosPreco.value = dadosRecebidos.map(function(item){
    return item.valorPreco;
}).join('');

//// MONTAGEM DA URL /////
document.getElementById("button_confirmar").addEventListener("click", function(event){
    var id = document.getElementById("id").value;
    var user = document.getElementById("user").value;
    var origem = document.getElementById("origem").value;
    var destino = document.getElementById("destino").value;
    var trajeto = document.getElementById('trajeto').value;
    var classe = document.getElementById('classe').value;
    var dataida = document.getElementById('dataida').value;
    var passageiros = document.getElementById('passageiros').value;
    var preco = document.getElementById('preco').value;


    var url = 'confirmar_pagamento.html?origem=' + encodeURIComponent(origem) +
        '&destino=' + encodeURIComponent(destino) + '&trajeto=' + encodeURIComponent(trajeto) +
        '&classe=' + encodeURIComponent(classe) + '&dataida=' + encodeURIComponent(dataida) +
        '&passageiros=' + encodeURIComponent(passageiros) +'&preco=' + encodeURIComponent(preco) + '&id=' + encodeURIComponent(id) + '&user=' + encodeURIComponent(user);
    window.location.href = url;

    event.preventDefault();
;})


