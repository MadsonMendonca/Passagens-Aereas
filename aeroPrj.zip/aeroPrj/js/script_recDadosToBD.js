document.getElementById("button_confirmar").addEventListener("click", function() {
    const urlParams = new URLSearchParams(window.location.search);
    const userID = urlParams.get('id');
    const user = urlParams.get('user');
    const origem = urlParams.get('origem');
    const destino = urlParams.get('destino');
    const classe = urlParams.get('classe');
    const data = urlParams.get('dataida');
    const passageiros = urlParams.get('passageiros');
    const precoTotal = urlParams.get('preco');

    var passageirosArmazenados = JSON.parse(localStorage.getItem('passageiros')) || [];
    
    // Array para armazenar os dados dos passageiros
    var dadosPassageiros = [];
    
    passageirosArmazenados.forEach(function(passageiro) {
        var nomePassageiro = passageiro.nome;
        var cpfPassageiro = passageiro.cpf;
        var poltronaID = passageiro.poltronaId;
        var precoUnitario = parseFloat(precoTotal) / parseFloat(passageiros);

        // Adiciona os dados do passageiro ao array
        dadosPassageiros.push({
            nomePassageiro: nomePassageiro,
            cpfPassageiro: cpfPassageiro,
            poltronaID: poltronaID,
            precoUnitario: precoUnitario
        });
    });    

    // Envia os dados para o servidor
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "https://localhost/aeroPrj/DadosToBD.php", true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function(){
        if (xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status === 200){
                console.log('Dados enviados com sucesso!');
            } else{
                console.error('Erro ao enviar os dados:', xhr.statusText);
            }
        }
    };

    // Envia os dados capturados da URL e do LocalStorage para o servidor
    xhr.send(JSON.stringify({
        userID: userID,
        user: user,
        origem: origem,
        destino: destino,
        classe: classe,
        data: data,
        passageiros: passageiros,
        precoTotal: precoTotal,
        passageirosArmazenados: dadosPassageiros // Envia os dados do bilhete para o servidor
    }));

    var url = 'index.php?id=' + encodeURIComponent(userID) + '&user=' + encodeURIComponent(user);

    window.location.href = url;
    alert("Compra efetuada com sucesso!")
});
