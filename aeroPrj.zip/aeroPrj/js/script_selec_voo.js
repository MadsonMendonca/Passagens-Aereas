//// CONVERTER ADULTO + CRIANCA EM PASSAGEIROS //// (OK)

function obterParametrosURL() {
    var url = window.location.search.substring(1); // Obtém a parte da URL após o "?"
    var parametros = url.split('&'); // Separa os dados pelo &
    var parametrosObj = {};

    for (var i = 0; i < parametros.length; i++) {
        var pair = parametros[i].split('=');
        parametrosObj[pair[0]] = pair[1];
    }
    return parametrosObj;
}

// Função para somar adultos e crianças e exibir o total
function calcularTotalPassageiros() {
    var parametros = obterParametrosURL(); 
    var adulto = parseInt(parametros['adulto']) || 0; 
    var crianca = parseInt(parametros['crianca']) || 0; 
    var total = adulto + crianca;

    document.getElementById('adulto').value = adulto;
    document.getElementById('crianca').value = crianca;
    document.getElementById('passageiros').value = total;
    return total;

}
calcularTotalPassageiros();

//// GERANDO DIVS ALEATORIAS ////
function obterParametroDaURL(nome) {
    nome = nome.replace(/[[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + nome + "=([^&#]*)");
    var resultados = regex.exec(location.search);
    return resultados === null ? "" : decodeURIComponent(resultados[1].replace(/\+/g, " "));
}

// Função para calcular o preço das passagens com base na classe selecionada
function precoPassagem(precoUnitario, classeValue) {

    if (classeValue === "Economic") {
        x = 1;
        return precoUnitario;
    } else if (classeValue === "Premium") {
        x = 1.5;
        return precoUnitario * 1.5;
    } else if (classeValue === "Premium-Plus") {
        x = 2;
        return precoUnitario * 2;
    }
}

// Função para criar uma div de passagem com botão "Reservar"
function criarDivPassagem(precoTotal, precoUnitario, origemValue, destinoValue, dataidaValue, classeValue, hora, minutos, i) {
    var div = document.createElement('div');
    div.classList.add('random-div');

    ///////// ALTERAR AQUI PARA MUDAR OS VALORES DE CADA DIV ////////////
    div.innerHTML = `<br>
    &nbsp; &nbsp; &nbsp; &nbsp;🛫 ${origemValue} &nbsp; &nbsp; &rarr; &nbsp; &nbsp; 🛬 ${destinoValue} &nbsp; &nbsp; &nbsp; &nbsp;<br><br>
    &nbsp; &nbsp; &nbsp; &nbsp;💵 Total R$ ${precoTotal.toFixed(2)} (R$ ${(precoUnitario *x).toFixed(2)} unit.) &nbsp; &nbsp; &nbsp; 🕰️ ${hora} horas e ${minutos} minutos &nbsp; &nbsp; &nbsp; &nbsp;🎫 ${classeValue}<br><br><br>
    `;
    
    var botaoReservar = document.createElement('button');
    botaoReservar.classList.add('btn', 'reservar-btn');
    botaoReservar.textContent = 'Reservar!';
    botaoReservar.style.backgroundColor = "rgb(165, 163, 42)";
    botaoReservar.style.color = "white";
    botaoReservar.style.borderRadius = "10px";
    botaoReservar.style.padding = "10px";
    botaoReservar.style.position = "absolute"
    botaoReservar.style.marginLeft = "750px"
    botaoReservar.style.marginTop = "-85px"
    botaoReservar.style.marginBottom = "10px"
    botaoReservar.style.cursor = "pointer"

    botaoReservar.addEventListener('click', function() {
        var id = document.getElementById("id").value;
        var user = document.getElementById("user").value;
        var origem = document.getElementById("origem").value;
        var destino = document.getElementById("destino").value;
        var trajeto = document.getElementById('trajeto').value;
        var classe = document.getElementById('classe').value;
        var dataida = document.getElementById('dataida').value;
        var datavolta = document.getElementById('datavolta').value;
        var passageiros = document.getElementById('passageiros').value;

        var url = 'selecionarAssento.php?origem=' + encodeURIComponent(origem) +
            '&destino=' + encodeURIComponent(destino) + '&trajeto=' + encodeURIComponent(trajeto) +
            '&classe=' + encodeURIComponent(classe) + '&dataida=' + encodeURIComponent(dataida) +
            '&datavolta=' + encodeURIComponent(datavolta) + '&passageiros=' + encodeURIComponent(passageiros) +
            '&preco=' + encodeURIComponent(precoTotal) + '&id=' + encodeURIComponent(id) + '&user=' + encodeURIComponent(user);
        window.location.href = url;
    });
    div.appendChild(botaoReservar);

    return div;
}


// Função principal para gerar as divs de passagem
function gerarDivsAleatorias() {
    var origemValue = obterParametroDaURL("origem");
    var destinoValue = obterParametroDaURL("destino");
    var classeValue = obterParametroDaURL("classe");
    var dataidaValue = obterParametroDaURL("dataida")
    var container = document.getElementById('container');
    var quantidade = Math.floor(Math.random() * 3) + 3;

    var precoUnitario = 170;     

    for (var i = 0; i < quantidade; i++) {
        precoUnitario += Math.floor(Math.random() * 51);
        var hora = Math.floor(Math.random() * 2) + 2;
        var minutos = Math.floor(Math.random() * 59) + 0;
        var precoTotal = precoPassagem(precoUnitario, classeValue) * calcularTotalPassageiros();
        var divPassagem = criarDivPassagem(precoTotal, precoUnitario, origemValue, destinoValue, dataidaValue, classeValue, hora, minutos, i);
        container.appendChild(divPassagem);
    }

}
document.addEventListener('DOMContentLoaded', function() {
    gerarDivsAleatorias();
});




