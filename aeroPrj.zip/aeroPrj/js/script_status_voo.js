var xhr = new XMLHttpRequest();
xhr.open('GET', 'php/php_status_voo.php', true);
xhr.onreadystatechange = function() {
    if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
            var dados = JSON.parse(xhr.responseText);
            var dadosBody = document.getElementById('dados-body');
            var user = localStorage.getItem('user'); // Obtém o usuário do Local Storage
            
            // Filtra os dados de acordo com o usuário do Local Storage
            dados.forEach(function(dado) {
                if (dado.user === user) { // Verifica se o usuário do dado é igual ao usuário do Local Storage
                    var row = document.createElement('tr');
                    row.innerHTML = '<td>' + dado.userID + '</td>' +
                                    '<td>' + dado.user + '</td>' +
                                    '<td>' + dado.id_pedido + '</td>' +
                                    '<td>' + dado.origem + '</td>' +
                                    '<td>' + dado.destino + '</td>' +                                    
                                    '<td>' + dado.classe + '</td>' +
                                    '<td>' + dado.data + '</td>' +
                                    '<td>' + dado.passageiros + '</td>' +
                                    '<td>' + dado.precoTotal + '</td>'+
                                    '<td><button class="btn-atualizar" data-id="' + dado.id_pedido + '">A</button></td>' +
                                    '<td><button class="btn-deletar" data-id="' + dado.id_pedido + '">D</button></td>';
                    dadosBody.appendChild(row);
                }
            });
    
            // ATUALIZAR
            document.querySelectorAll('.btn-atualizar').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var idPedido = this.getAttribute('data-id');
                    var modal = document.getElementById('myModal');
                    modal.style.display = 'block';
                    
                    var btnSave = document.getElementById('btnSalvar');
                    btnSave.addEventListener('click', function() {
                        var novaOrigem = document.getElementById('novaOrigem').value;
                        var novoDestino = document.getElementById('novoDestino').value;
                        var novaClasse = document.getElementById('novaClasse').value;
                        var novaData = document.getElementById('novaData').value;
                        
                        modal.style.display = 'none';                                               
                        
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', 'php/php_status_voo.php');
                        xhr.setRequestHeader('Content-Type', 'application/json');
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState === XMLHttpRequest.DONE) {
                                if (xhr.status === 200) {
                                    alert('Dados atualizados com sucesso!');
                                    location.reload();
                                } else {
                                    alert('Erro ao atualizar os dados!');
                                }       
                            }   
                        };
                        xhr.send(JSON.stringify({ idPedido: idPedido, novaOrigem: novaOrigem, novoDestino: novoDestino, novaClasse: novaClasse, novaData: novaData }));
                    });
                    
                    var span = document.getElementsByClassName('close')[0];
                    span.onclick = function() {
                        modal.style.display = 'none';
                    }
                });
            });
            
            /// DELETAR
            document.querySelectorAll('.btn-deletar').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var idPedido = this.getAttribute('data-id');
                    var data = { idPedido: idPedido };
                    
                    var xhr = new XMLHttpRequest();
                        xhr.open('DELETE', 'php/php_status_voo.php');
                        xhr.setRequestHeader('Content-Type', 'application/json');
                        xhr.onreadystatechange = function() {
                            if (xhr.readyState === XMLHttpRequest.DONE) {
                                if (xhr.status === 200) {
                                    alert('Dados deletados com sucesso!');
                                    location.reload();
                                } else {
                                    alert('Erro ao deletar os dados!');
                                }       
                            }   
                        };
                    xhr.send(JSON.stringify(data));

                    console.log('Deletar dados do pedido ID:', idPedido);
                });
            });            
        } else {
            console.error('Erro na requisição: ' + xhr.status);
        }
    }
};
xhr.send();

// montagemm da url

document.getElementById('BtnPassagem').addEventListener('click', function(){
    var urlParams = new URLSearchParams(window.location.search);
    var id = urlParams.get('id');
    var user = urlParams.get('user');

    var url = 'status_voo2.html?id=' + encodeURIComponent(id) + '&user=' + encodeURIComponent(user);
    window.location.href = url;
    
});
