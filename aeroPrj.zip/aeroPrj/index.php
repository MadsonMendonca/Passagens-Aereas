<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_index.css">
    <link rel="stylesheet" href="css/style_cabecalho.css">
    <title>BEM VINDO À NORDESTE AIRLINES</title>
</head>
<body>
    <input type="text" id="id" hidden>
    <input type="text" id="user" hidden>
    <div id="cabecalho">
        <div id="cabecalho-logo">
            <img src="imagens\logo_ajustada.png" alt="logo" id="logo">
        </div><!--fim div logo-->
        <div id="cabecalho-1">
            <div id="cabecalho-11">
                <select id="select-1" onchange="window.location.href=this.value;">
                    <option value="" disabled selected>Ofertas e Destinos</option>
                    <option value="construt.html">Ofertas de Voos</option>
                    <option value="construt.html">Destinos</option>
                    <option value="construt.html">Hotéis, carros e pacotes</option>
                </select>

            </div>
            <div id="cabecalho-12">
                <select id="select-2" onchange="window.location.href=this.value;">
                    <option value="" disabled selected>Minhas Viagens</option>
                    <option value="construt.html">Administre suas viagens</option>
                    <option value="construt.html">Check-in</option>
                </select>
            </div>
            <div id="cabecalho-13">
                <a href="construt.html"><p>Central de Ajuda</p></a>
            </div>
        </div>    
            
        <div id="cabecalho-2">   
            <div id="cabecalho-21">
                <p id="status_voo">Status de Voos</p>
            </div>
            <div id="cabecalho-22">
                <select name="cabecalho-22" id="cabecalho-22">                    
                    <option value="brl" class="option-brl">BRL - R$</option>
                    <option value="usd" class="option-usd">USD - US$</option>
                    <option value="eur" class="option-eur">EUR - &#8364;</option>
                </select> 
            </div>
            
            <div id="cabecalho-23">
                <a href="login.html"><button type="submit" id="button-login-cabecalho" onclick="fazerLogin()">&nbsp; &nbsp; Fazer &nbsp; &nbsp; <br> &nbsp; &nbsp; Login &nbsp; &nbsp; </button></a>
            
            </div>
            <div id="button_sair">
                <a href="php/logout.php" >Sair</a>
            </div>
        </div>
            
        </div><!--fim div informacao do cabecalho-->
    </div> <!--fim div cabecalho-->

    <br><br><br><br>

    <div id="balao">
        <h5>INFORMAÇÕES URGENTES</h5>        
        <div id="balao_de_informacoes">               
            <marquee>Lamentamos informar que o voo para Fortaleza foi cancelado devido a condições meteorológicas adversas. Devido às fortes chuvas e tempestades na região Nordeste do Brasil, o aeroporto de Fortaleza está temporariamente fechado. Estamos trabalhando para reacomodar todos os passageiros afetados em voos alternativos o mais rápido possível. Para mais informações, entre em contato conosco pelo telefone 0800-123-4567. Agradecemos a sua compreensão.</marquee>
            <button id="fecharBalao">X</button>
        </div>
    </div> <!--fim div balao de informacao-->

    <br>

    <div id="corpo-imagem-fundo">
        <br><br><br>
        <div id="corpo-selecionar-voo">
            <div class="tab">
                <button class="tablinks" onclick="openTab(event, 'aba1')">Voos</button>
                <button class="tablinks" onclick="openTab(event, 'aba2')">Pacotes</button>
                <button class="tablinks" onclick="openTab(event, 'aba3')">Hóteis</button>
                <button class="tablinks" onclick="openTab(event, 'aba4')">Seguros</button>
            </div>         
            
            <div id="aba1" class="tabcontent">
                <header>Para onde deseja ir?</header><br>
                <input list="lista-aeroportos" type="text" id="origem" class="trajeto_origem" placeholder="Origem">
                <input list="lista-aeroportos" type="text" id="destino" class="trajeto_destino" placeholder="Destino">
                
                <datalist id="lista-aeroportos">
                    <option value="AL - Maceió (MCZ)">MACEIÓ, Aerpt. Intl. Zumbi dos Palmares (MCZ/SBMO)</option>
                    <option value="BA - Salvador (SSA)">SALVADOR, Aerpt. Intl. Deputado Luís Eduardo Magalhães (SSA/SBSV)</option>
                    <option value="CE - Fortaleza (FOR)">FORTALEZA, Aerpt. Intl. Pinto Martins (FOR/SBFZ)</option>
                    <option value="MA - São Luis(SLZ)">SÃO LUÍS, Aerpt. Intl. Marechal Hugo da Cunha Machado (SLZ/SBSL)</option>
                    <option value="PB - João Pessoa (JPA)">JOÃO PESSOA, Aerpt. Intl. Presidente Castro Pinto (JPA/SBJP)</option>
                    <option value="PE - Recife (REC)">RECIFE, Aerpt. Intl. dos Guararapes Gilberto Freyre (REC/SBRF)</option>
                    <option value="PI - Teresina (THE)">TERESINA, Aerpt. Intl. de Teresina (THE/SBTE)</option>
                    <option value="RN - Natal (NAT)">NATAL, Aerpt. Intl. Governador Aluízio Alves (NAT/SBSG)</option>
                    <option value="SE - Aracaju (AJU)">ARACAJU, Aerpt. Intl. de Aracaju (AJU/SBAR)</option>
                </datalist>

                <br><hr>

                <header>Informações da viagem</header><br>
                <select name="trajeto" id="trajeto">
                    <option value="ida e volta">Ida e Volta</option>
                    <option value="ida">Somente Ida</option>                
                </select>     
                
                <select id="classe-economica">
                    <option value="Economic">Economic</option>
                    <option value="Premium">Premium</option>
                    <option value="Premium-Plus">Premium-Plus</option>
                </select>

                <select id="passageiros">
                    <option value="passageiro1">Adulto</option>
                    <option value="passageiro2">Adulto e criança</option>
                                   

                </select>
                
                <hr>   
                
                <header>Selecione a data da viagem</header><br>
                <div id="data1">
                    <label>Ida</label><br>
                    <input type="date" id="dataida" class="trajeto_data_ida" onchange="validarDatas()">
                </div>
                <div id="data2">
                    <label>Volta</label><br>
                    <input type="date" id="datavolta" class="trajeto_data_volta" onchange="validarDatas()">
                </div>
                <hr>
                
                <header>Quantidade de passageiros</header><br>
                <label id="lab-adulto">Adultos</label>   
                <input type="number" value="1" min="1" max="5" id="qtd-passag-adulto" >
                <label id="lab-crianca">Crianças</label>   
                <input type="number" value="0" min="0" max="5" id="qtd-passag-crianca" disabled>
                
                <br><br><br>
                <button id="irParaProximaPagina" type="submit">PROCURAR</button> <br><br>                          

            </div><!-- Fim da Aba 1-->
            
            <div id="aba2" class="tabcontent">
                <header>Para onde deseja ir?</header><br>
                <input type="text" class="trajeto_origem" placeholder="Origem">
                <input type="text" class="trajeto_destino" placeholder="Destino"><br><hr>

                <header>Pacote (voo + quarto)</header>

                <select id="classe-economica">
                    <option value="classe3">2 Adultos</option>
                    <option value="classe2">2 Adultos e 1 Criança</option>
                    <option value="classe1">Mais opções na próxima página</option>
                </select>
                               
                <hr>   
                
                <header>Selecione a data da viagem</header><br>
                <div id="data1">
                    <label>Ida</label><br>
                    <input type="date" class="trajeto_data_ida">
                </div>
                <div id="data2">
                    <label>Volta</label><br>
                    <input type="date" class="trajeto_data_volta">
                </div>

                <br><br><br>
                <button type="submit" id="button-procurar"><a href="construt.html"></a>PROCURAR</a></button> <br><br>            
            </div><!-- Fim da Aba 2-->
            
            <div id="aba3" class="tabcontent">
                <header>Onde deseja alugar uma acomodação?</header><br>
                <input type="text" class="trajeto_destino" placeholder="Destino"><br><hr>

                <header>Informações da acomodação</header><br>                 
                
                <select id="classe-economica">
                    <option value="classe3">Apartamento</option>
                    <option value="classe2">Casa</option>
                    <option value="classe1">Hostel</option>
                </select>

                <select id="passageiros">
                    <option value="passageiro1">Adulto</option>
                    <option value="passageiro2">Adulto e criança</option>
                    <option value="passageiro3">Adulto e bebê</option>
                    <option value="passageiro4">Adulto, criança e bebê</option>
                </select>

                <input type="checkbox" id="checkbox-petfriendly" placeholder="petfriendly">
                <label for="" id="petfriendly">PetFriendly</label>

                <hr>   
                
                <header>Selecione o período da estadia</header><br>
                <div id="data1">
                    <label>Entrada</label><br>
                    <input type="date" class="trajeto_data_ida">
                </div>

                <div id="data2">
                    <label>Saída</label><br>
                    <input type="date" class="trajeto_data_volta">
                </div>

                <hr>

                <header>Quantidade de hóspedes</header><br>
                <label id="lab-adulto">Adultos</label>   
                <input type="number" value="1" min="0" max="9" id="qtd-passag-adulto" >
                <label id="lab-crianca">Crianças</label>   
                <input type="number" value="0" min="0" max="9" id="qtd-passag-crianca" disabled>
                <label id="lab-bebe">Bebês</label>   
                <input type="number" value="0" min="0" max="9" id="qtd-passag-bebe" disabled>   
                <br><br><br>
                <a href="construt.html"><button type="submit" id="button-procurar">PROCURAR</button></a> <br><br>
            </div><!-- Fim da Aba 3-->
            
            <div id="aba4" class="tabcontent">
                <header>Os melhores seguros para a sua viagem estão na NORDESTE Airlines!</header><br><br>
                <a href="construt.html"><button type="submit" id="button-procurar">PROCURAR</button></a><br><br>

            </div><!-- Fim da Aba 4-->


            

        </div><!--fim div selecionar voo-->
        <br><br><br>
    </div> <!--fim div imagem fundo da tela selecionar voo-->    
    
    <div>
        <div id="card-informacao">
            <a href="construt.html" id="texto-card"><div id="card-informacao1">
                <div id="img-card">
                    <span style='font-size:40px;'>&#128746;</span>
                </div>
                <div id="paragrafo-card">
                    <p>Administre sua viagem</p>
                </div>                
            </div></a>

            <div id="card-informacao2"><a href="construt.html" id="texto-card">
                <div id="img-card">
                    <span style='font-size:35px;'>&#128221;</span>

                </div>
                <div id="paragrafo-card">
                    <p>Remarcação ou reembolso <br> de passagem</p>
                </div>
            </div></a>

            <a href="construt.html" id="texto-card"><div id="card-informacao3">
                <div id="img-card">
                    <span style='font-size:35px;'>&#128178;</span>
                </div>
                <div id="paragrafo-card">
                    <p>Informações sobre <br>taxas de embarque</p>
                </div>
            </div></a>

            <a href="construt.html" id="texto-card"><div id="card-informacao4">
                <div id="img-card">
                    <span style='font-size:30px;'>&#128188;</span>
                </div>
                <div id="paragrafo-card">
                    <p>Informações sobre <br>bagagem</p>
                </div>
            </div></a>
        </div>

    </div><br><br> <!--fim div botoes de informacao-->
    <div>
        <h2>Confira as melhores ofertas</h2>
        <p id="paragrafo">Ofertas de voos sainde de
        <select name="promocoes-voo" id="promocoes-voo">
            <option value="MCZ">Aeroporto Internacional de Maceió - Zumbi dos Palmares (MCZ/SBMO)</option>
            <option value="SSA">Aeroporto Internacional de Salvador - Deputado Luís Eduardo Magalhães (SSA/SBSV)</option>
            <option value="FOR">Aeroporto Internacional de Fortaleza - Pinto Martins (FOR/SBFZ)</option>
            <option value="SLZ">Aeroporto Internacional de São Luís - Marechal Hugo da Cunha Machado (SLZ/SBSL)</option>
            <option value="JPA">Aeroporto Internacional de João Pessoa - Presidente Castro Pinto (JPA/SBJP)</option>
            <option value="REC">Aeroporto Internacional dos Guararapes Gilberto Freyre (REC/SBRF)</option>
            <option value="THE">Aeroporto Internacional de Teresina (THE/SBTE)</option>
            <option value="NAT">Aeroporto Internacional de Natal - Governador Aluízio Alves (NAT/SBSG)</option>
            <option value="AJU">Aeroporto Internacional de Aracaju (AJU/SBAR)</option>

            
        </select></p>

        <div id="promocao-principal1">
            <span class="text-overlay2">OFERTA</span>
            <span class="text-overlay3">Natal</span>
            <span class="text-overlay4">Preços a partir de <b>R$ 149,90</b></span>
            <img src="imagens/natal.png" alt="natal" id="img_natal">
        </div>

        <div id="promocao-principal2">
            <div id="promocao-secundaria1">
                <span class="text-overlay2">OFERTA</span>
                <span class="text-overlay5">Recife</span>
                <img src="imagens/recife.jpg" alt="recife" id="img_recife">
            </div>
            <div id="promocao-secundaria2">
                <span class="text-overlay2">OFERTA</span>
                <span class="text-overlay5">São Luís</span>
                <img src="imagens/sao-luis.jpg" alt="sao luis" id="img_saoluis">
            </div>

        </div>
        
    </div><br><br><!--fim div promocoes-->
   
    <div id="destino-star">
        <h2>Conheça os destinos mais procurados </h2>
        <div id="destino-star1">
            <span class="text-overlay">FORTALEZA</span>
            <img src="imagens/fortaleza.png" alt="fortaleza" id="img_fortaleza">
        </div>
        <div id="destino-star2">
            <span class="text-overlay">MACEIÓ</span>
            <img src="imagens/maceio.png" alt="maceio" id="img_maceio">
        </div>
        <div id="destino-star3">
            <span class="text-overlay">SALVADOR</span>
            <img src="imagens/salvador.png" alt="salvador" id="img_salvador">
        </div>
        <div id="destino-star4">
            <span class="text-overlay">JOÃO PESSOA</span>
            <img src="imagens/jampa.png" alt="João Pessoa" id="img_jampa">
        </div>
    </div><!--fim div dos destinos mais procurados-->
  
    <div id="rodape1">
        <div id="rodape-lista">
            <h4>NORDESTE Airlines</h4>
            <a href="index.html" id="rodape-link"><p>Início</p></a>
            <a href="construt.html" id="rodape-link"><p>Sobre a NORDESTE Airlines</p></a>
            <a href="construt.html" id="rodape-link"><p>Experiência NORDESTE Airlines</p></a>
            <a href="construt.html" id="rodape-link"><p>Prepare sua viagem</p></a>
            <a href="construt.html" id="rodape-link"><p>Minhas viagens</p></a>
            <a href="construt.html" id="rodape-link"><p>Status de voo</p></a>
            <a href="construt.html" id="rodape-link"><p>Check-in</p></a>
            <a href="construt.html" id="rodape-link"><p>Destinos</p></a>
            <a href="construt.html" id="rodape-link"><p>Crie sua conta</p></a>
            <a href="construt.html" id="rodape-link"><p>Central de ajuda</p></a>
        </div>

        <div id="rodape-lista">
            <h4>Informação legal</h4>
            <a href="construt.html" id="rodape-link"><p>Contrato de transporte aéreo</p></a>
            <a href="construt.html" id="rodape-link"><p>Política de privacidade e segurança</p></a>
            <a href="construt.html" id="rodape-link"><p>Política de Cookies</p></a>
            <a href="construt.html" id="rodape-link"><p>Dicas de segurança</p></a>
            <a href="construt.html" id="rodape-link"><p>Gestão de sustentabilidade</p></a>
            <a href="construt.html" id="rodape-link"><p>Diversidade</p></a>            
        </div>

        <div id="rodape-lista">
            <h4>Portais associados</h4>
            <a href="construt.html" id="rodape-link"><p>NORDESTE Vip</p></a>
            <a href="construt.html" id="rodape-link"><p>Pacotes, hotéis e mais</p></a>
            <a href="construt.html" id="rodape-link"><p>Trabalhe conosco</p></a>
            <a href="construt.html" id="rodape-link"><p>Relações com investidores</p></a>                      
        </div>
        <div id="rodape-lista">
            <h4>Acessibilidade</h4>
            <img src="imagens/conselhos-municipais-o-simbolo-de-acessibilidade-logo-universal.png" alt="img-acessibilidade" id="img_acessibilidade"><br>
            <h4>Entre em contato conosco</h4>
            <img src="imagens/redessociais.png" alt="icone-redes-sociais" id="img_redes"><br>
            <h4>Nosso app no seu telefone</h4>
            <img src="imagens/store.png" alt="img-app-store" id="img_store">
        </div>
        

    </div>
    
    <hr>
    
    <div id="rodape2">
        <div id="rodape-logo">
            <img src="imagens\logo_ajustada.png" alt="logo" id="logo"></div>
        <div id="rodape-endereco">
            <p>© 2024 NORDESTE Airlines Ltda. Av. Senador Fernandes Távora n° 137, sala F206, CEP 60510-111, Fortaleza/CE CNPJ: 00.099.888/0000-99</p>
        </div>
        <div id="rodape-autores">
            <p>Produzido por: Madson Mendonça | Wellington | Bruno  | Morgana | Isaac</p>
        </div><br>


    </div>


    

    <script src="js/script_index_valid_url.js"></script>
    <script src="js/script_index.js"></script>
    <script src="js/script_cabecalho.js"></script>
</body>
</html>