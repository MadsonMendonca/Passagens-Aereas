<?php session_start(); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style_selec_voo.css">
    <link rel="stylesheet" href="css/style_cabecalho.css">
    <title>SELECIONAR VOO</title>
</head>
<body>
    <input type="text" id="id" hidden>
    <input type="text" id="user" hidden>
    <div id="cabecalho">
        <div id="cabecalho-logo">
            <img src="imagens\logo_ajustada.png" alt="logo" id="logo">
        </div><!--fim div logo-->
        <div id="cabecalho-1">
            <div id="cabecalho-11">
                <select id="select-1" onchange="window.location.href=this.value;">
                    <option value="" disabled selected>Ofertas e Destinos</option>
                    <option value="construt.html">Ofertas de Voos</option>
                    <option value="construt.html">Destinos</option>
                    <option value="construt.html">Hotéis, carros e pacotes</option>
                </select>

            </div>
            <div id="cabecalho-12">
                <select id="select-2" onchange="window.location.href=this.value;">
                    <option value="" disabled selected>Minhas Viagens</option>
                    <option value="construt.html">Administre suas viagens</option>
                    <option value="construt.html">Check-in</option>
                </select>
            </div>
            <div id="cabecalho-13">
                <a href="construt.html"><p>Central de Ajuda</p></a>
            </div>
        </div>    
            
        <div id="cabecalho-2">   
            <div id="cabecalho-21">
                <p id="status_voo">Status de Voos</p>
            </div>
            <div id="cabecalho-22">
                <select name="cabecalho-22" id="cabecalho-22">                    
                    <option value="brl" class="option-brl">BRL - R$</option>
                    <option value="usd" class="option-usd">USD - US$</option>
                    <option value="eur" class="option-eur">EUR - &#8364;</option>
                </select> 
            </div>
            
            <div id="cabecalho-23">
                <a href="login.html"><button type="submit" id="button-login-cabecalho" onclick="fazerLogin()">&nbsp; &nbsp; Fazer &nbsp; &nbsp; <br> &nbsp; &nbsp; Login &nbsp; &nbsp; </button></a>            
            </div>
            
            <div id="button_sair">
                <a href="php/logout.php" >Sair</a>
            </div>
        </div>
            
        </div><!--fim div informacao do cabecalho-->
    </div> <!--fim div cabecalho-->
    
    <br><br><br><br><br>

    <div class="dadosRecebidos">
        <div class="origem">
            <label for="">Origem</label><br>
            <input type="text" id="origem" disabled>
        </div>
        <div class="destino">
            <label for="">Destino</label><br>
            <input type="text" id="destino" disabled>
        </div>
        <div class="trajeto">
            <label for="" hidden>Trajeto</label><br>
            <input type="text" id="trajeto" disabled hidden>
        </div>
        <div class="classe">
            <label for="">Classe</label><br>
            <input type="text" id="classe" disabled>
        </div>
        <div class="dataida">
            <label for="">Data da viagem</label><br>
            <input type="date" id="dataida" disabled>
        </div>        
        <div class="passageiros">
            <label> Passageiros</label><br>
            <input type="number" id="passageiros" disabled>
            <label for="" hidden>Adulto</label>
            <input type="number" id="adulto" disabled hidden>
            <label for="" hidden>Criança</label>
            <input type="number" id="crianca" disabled hidden>
        </div>
        <div class="datavolta">
            <label for="" hidden>Data Volta</label>
            <input type="date" id="datavolta" disabled hidden>
        </div>
        
    </div> <!-- Fim da div Dados Recebidos-->
    
    <h2>Reserve seu voo e aproveite as nossas melhores ofertas!</h2>    

    <div id="container">

        
    </div> <!--Fim da div selecioonar os voos--> <br><br><br><br> 


    <div id="rodape1">
        <div id="rodape-lista">
            <h4>NORDESTE Airlines</h4>
            <a href="index.html" id="rodape-link"><p>Início</p></a>
            <a href="construt.html" id="rodape-link"><p>Sobre a NORDESTE Airlines</p></a>
            <a href="construt.html" id="rodape-link"><p>Experiência NORDESTE Airlines</p></a>
            <a href="construt.html" id="rodape-link"><p>Prepare sua viagem</p></a>
            <a href="construt.html" id="rodape-link"><p>Minhas viagens</p></a>
            <a href="construt.html" id="rodape-link"><p>Status de voo</p></a>
            <a href="construt.html" id="rodape-link"><p>Check-in</p></a>
            <a href="construt.html" id="rodape-link"><p>Destinos</p></a>
            <a href="construt.html" id="rodape-link"><p>Crie sua conta</p></a>
            <a href="construt.html" id="rodape-link"><p>Central de ajuda</p></a>
        </div>

        <div id="rodape-lista">
            <h4>Informação legal</h4>
            <a href="construt.html" id="rodape-link"><p>Contrato de transporte aéreo</p></a>
            <a href="construt.html" id="rodape-link"><p>Política de privacidade e segurança</p></a>
            <a href="construt.html" id="rodape-link"><p>Política de Cookies</p></a>
            <a href="construt.html" id="rodape-link"><p>Dicas de segurança</p></a>
            <a href="construt.html" id="rodape-link"><p>Gestão de sustentabilidade</p></a>
            <a href="construt.html" id="rodape-link"><p>Diversidade</p></a>            
        </div>

        <div id="rodape-lista">
            <h4>Portais associados</h4>
            <a href="construt.html" id="rodape-link"><p>NORDESTE Vip</p></a>
            <a href="construt.html" id="rodape-link"><p>Pacotes, hotéis e mais</p></a>
            <a href="construt.html" id="rodape-link"><p>Trabalhe conosco</p></a>
            <a href="construt.html" id="rodape-link"><p>Relações com investidores</p></a>                      
        </div>
        <div id="rodape-lista">
            <h4>Acessibilidade</h4>
            <img src="imagens/conselhos-municipais-o-simbolo-de-acessibilidade-logo-universal.png" alt="img-acessibilidade" id="img_acessibilidade"><br>
            <h4>Entre em contato conosco</h4>
            <img src="imagens/redessociais.png" alt="icone-redes-sociais" id="img_redes"><br>
            <h4>Nosso app no seu telefone</h4>
            <img src="imagens/store.png" alt="img-app-store" id="img_store">
        </div>
        

    </div>
    <hr>
    <div id="rodape2">
        <div id="rodape-logo">
            <img src="imagens\logo_ajustada.png" alt="logo" id="logo">        </div>
        <div id="rodape-endereco">
            <p>© 2024 NORDESTE Airlines Ltda. Av. Senador Fernandes Távora n° 137, sala F206, CEP 60510-111, Fortaleza/CE CNPJ: 00.099.888/0000-99</p>
        </div>
        <div id="rodape-autores">
            <p>Produzido por: Madson Mendonça | Wellington | Bruno  | Morgana | Isaac</p>
        </div><br>


    </div>


    



    <script src="js/script_cabecalho.js"></script>
    <script src="js/script_selec_voo.js"></script> <!--SCRIPT PARA ALTERAR EFEITOS DA PAGINA-->
    <script src="js/script_selec_voo_dados.js"></script> <!--SCRIPT QUE ESTÁ RECEBENDO OS DADOS DA PAGINA INDEX-->
</body>
</html>
